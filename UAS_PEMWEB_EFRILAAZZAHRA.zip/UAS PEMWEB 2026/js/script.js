function validasiForm() {
    var nama = document.getElementById("nama").value;
    var jumlah = document.getElementById("jumlah").value;
    var kategori = document.getElementById("kategori").value;

    if (nama === "") {
        alert("Nama transaksi harus diisi!");
        return false;
    }

    if (jumlah === "") {
        alert("Jumlah transaksi harus diisi!");
        return false;
    }

    if (kategori === "") {
        alert("Silakan pilih kategori transaksi!");
        return false;
    }

    alert("Transaksi berhasil disimpan!");
    return false; // <-- PENTING, supaya halaman tidak reload
}
